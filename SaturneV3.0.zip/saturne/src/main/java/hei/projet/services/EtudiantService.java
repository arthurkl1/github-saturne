package hei.projet.services;

import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import java.util.logging.Logger;

import hei.projet.dao.EtudiantDao;
import hei.projet.dao.impl.EtudiantDaoImpl;
import hei.projet.entities.Etudiant;
import hei.projet.exceptions.SaturneSecuriteException;
import hei.projet.servlets.GenericSaturneServlet;
import hei.projet.utils.MotDePasseUtils;


public class EtudiantService {

	
	private static class EtudiantServiceHolder{
		private static EtudiantService instance = new EtudiantService();
	}
	
	public static EtudiantService getInstance(){
		return EtudiantServiceHolder.instance;
	}
	
	private EtudiantService(){
	}
	
	private static Logger LOGGER = Logger.getLogger(EtudiantService.class.getName());	
	private EtudiantDaoImpl etudiantDao = new EtudiantDaoImpl();
	private MotDePasseUtils motDePasseUtils = new MotDePasseUtils();
	
	public List<Etudiant> listEtudiant(){
		return etudiantDao.listEtudiants();
	}
	
	public Etudiant getEtudiant(Integer id){
		return etudiantDao.getEtudiant(id);
	}
	
	public Etudiant getEtudiantByMail(String email){
		return etudiantDao.getEtudiantByMail(email);
	}
	
	public Etudiant ajouterEtudiant(Etudiant etudiant, String mdp) throws SaturneSecuriteException {
		if ( etudiant.getEmail()== null || "".equals(etudiant.getEmail())){
			throw new IllegalArgumentException("L'adresse email doit être renseigné.");
		}
		Etudiant etudiantExistant = this.getEtudiantByMail(etudiant.getEmail());
        if (etudiantExistant != null) {
            throw new IllegalArgumentException("L'identifiant est déjà utilisé.");
        }
        
        String mdpHaser;
		try{
		 mdpHaser = motDePasseUtils.genererMotDePasse(mdp);
		} catch (GeneralSecurityException e){
			throw new SaturneSecuriteException("Problème dans la génération du mot de passe.");
		}
		Etudiant nouvelEtudiant = etudiantDao.addEtudiant(etudiant, mdpHaser);
		
		LOGGER.info(String.format("Etudiant|ajouterEtudiant|id=%d;email=%s", nouvelEtudiant.getId(), nouvelEtudiant.getEmail()));
		return etudiant;
	}
	
	public boolean validerMotDePasse(String email, String motDePasseAVerifier) throws SaturneSecuriteException {
		if (email == null || "".equals(email)) {
            throw new IllegalArgumentException("L'identifiant doit être renseigné.");
        }
        if (motDePasseAVerifier == null || "".equals(motDePasseAVerifier)) {
            throw new IllegalArgumentException("Le mot de passe doit être renseigné.");
        }
        String motDePasseHashe = etudiantDao.getMotDePasseEtudiantHashe(email);
        if (motDePasseHashe == null) {
            throw new IllegalArgumentException("L'identifiant n'est pas connu.");
        }
        try {
            return motDePasseUtils.validerMotDePasse(motDePasseAVerifier, motDePasseHashe);
        } catch (GeneralSecurityException e) {
            throw new SaturneSecuriteException("Problème dans la vérification du mot de passe.", e);
        }
    }
	
	
	public void modifierMotDePasse (int id, String motDePasse, String confirmationMotDePasse) throws SaturneSecuriteException{
		  if (motDePasse == null || "".equals(motDePasse) || confirmationMotDePasse == null || "".equals(confirmationMotDePasse)) {
	            throw new IllegalArgumentException("Les mots de passe doivent être renseignés.");
	        }
	        if (!motDePasse.equals(confirmationMotDePasse)) {
	            throw new IllegalArgumentException("La confirmation du mot de passe ne correspond pas.");
	        }
	        
	        try {
	        	String motDePasseHashe = motDePasseUtils.genererMotDePasse(motDePasse);
	        	etudiantDao.modifierMotDePasse(id, motDePasseHashe);
	        	System.out.println(motDePasseHashe);
	        } catch (GeneralSecurityException e) {
	            throw new SaturneSecuriteException("Problème dans la génération du mot de passe.", e);
	        }
	        LOGGER.info(String.format("Utilisateur|modifierMotDePasse|id=%d", id));
		}
	
	  public void enleverDroitsAdmin(Integer id) {
	        if (id == null) {
	            throw new IllegalArgumentException("L'id de l'utilisateur ne peut pas être null.");
	        }
	        etudiantDao.modifierRoleAdmin(id, false);
	        LOGGER.info(String.format("Etudiant|enleverDroitsAdmin|id=%d", id));
	    }

	    public void donnerDroitsAdmin(Integer id) {
	        if (id == null) {
	            throw new IllegalArgumentException("L'id de l'etudiant ne peut pas être null.");
	        }
	        etudiantDao.modifierRoleAdmin(id, true);
	        LOGGER.info(String.format("Etudiant|donnerDroitsAdmin|id=%d", id));
	    }

	
	
	
	
	public void removeEtudiant(Integer id){
		 if (id == null) {
	            throw new IllegalArgumentException("L'id de l'utilisateur ne peut pas être null.");
	        }
		etudiantDao.removeEtudiant(id);
	}
}
