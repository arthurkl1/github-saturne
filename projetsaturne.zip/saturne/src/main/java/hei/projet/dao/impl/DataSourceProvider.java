package hei.projet.dao.impl;

import javax.sql.DataSource;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

// Cette classe permet de se connecter à la BDD selon les informations adéquates

public class DataSourceProvider {
	
	private static MysqlDataSource dataSource;

	/*public static DataSource getDataSource() {
		if (dataSource == null) {
			dataSource = new MysqlDataSource();
			dataSource.setServerName("byxg2ky6b-mysql.services.clever-cloud.com");
			dataSource.setPort(3306);
			dataSource.setDatabaseName("byxg2ky6b"); //A changer nom schema
			dataSource.setUser("uqh4tdhfsua6u3pj");//A changer
			dataSource.setPassword("WxMam850FJfWSz5HkI6");//A changer pour adri :0000 /// pour arthur : hei2016-2017
		}
		return dataSource;
	} */

	
	public static DataSource getDataSource() {
		if (dataSource == null) {
			dataSource = new MysqlDataSource(); //création d'un objet datasource
			dataSource.setServerName("localhost"); //le nom du serveur
			dataSource.setPort(3306); // le port ( par défaut 3306)
			dataSource.setDatabaseName("saturne");// Nom du schéma
			dataSource.setUser("root");//Nom du user pour se connecter 
			dataSource.setPassword("0000");//mot de passe associé au user
		}
		return dataSource;
	}

}
