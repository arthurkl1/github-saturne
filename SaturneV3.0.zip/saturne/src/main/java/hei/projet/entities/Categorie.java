package hei.projet.entities;

public class Categorie {
	
	private Integer id;
	private String nom;
	private String localisation;
	
	public Categorie(Integer id, String nom, String localisation){
		super();
		this.id = id;
		this.nom = nom;
		this.localisation=localisation;
	}

	public String getLocalisation() {
		return localisation;
	}

	public void setLocalisation(String localisation) {
		this.localisation = localisation;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	

}
