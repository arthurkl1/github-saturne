package hei.projet.entities;


import java.time.LocalDate;

//Cette classe permet de représenter la table evenement de la base de données sous forme d'objet Java

public class Evenement {
	
	//Attribut de la classe Evenement
	private Integer idEvenement;
	private String titleEvenement;
	private String lieuEvenement;
	private LocalDate dateEvenement;
	private Categorie categorie;
	private String descriptionEvenement;
	
	/**
    Constructeur de la classe Evenement
    @param idEvenement L'id de l'evenement.  
    @param titleEvenement Le titre de l'evenement. 
    @param lieuEvenement Le lieu de l'evenement.
    @param dateEvenement La date de l'evenement.
    @param categorie Le categorie à laquelle appartient l'evenement.
     @param descriptionEvenement La description de l'evenement.
	 */
	public Evenement(Integer idEvenement, String titleEvenement, 
			String lieuEvenement, LocalDate dateEvenement,
			Categorie categorie, String descriptionEvenement){		
	super();
	this.idEvenement = idEvenement;
	this.titleEvenement = titleEvenement;
	this.lieuEvenement = lieuEvenement;
	this.dateEvenement = dateEvenement;
	this.categorie = categorie; 
	this.setDescriptionEvenement(descriptionEvenement);
	}
	
	
	/**
    Lire l'identifiant d'un evenement. 
    @return L'identifiant d'un evenement. 
	 */
	public Integer getIdEvenement() {
		return idEvenement;
	}
	
	/**
    Alterer l'id d'un évènement. 
    @param idEvenement L'id de l'évènement. 
	 */
	public void setIdEvenement(Integer idEvenement) {
		this.idEvenement = idEvenement;
	}

	/**
    Lire le titre d'un evenement. 
    @return Le titre de l'evenement. 
	 */
	public String getTitleEvenement() {
		return titleEvenement;
	}

	/**
    Alterer le titre d'un évènement.
    @param titleEvenement Le titre de l'évènement. 
	 */
	public void setTitleEvenement(String titleEvenement) {
		this.titleEvenement = titleEvenement;
	}

	/**
    Lire le lieu d'un évènement. 
    @return L'identifiant d'une catégorie. 
	 */
	public String getLieuEvenement() {
		return lieuEvenement;
	}

	/**
    Alterer le lieu d'un évènement. 
    @param lieuEvenement Le lieu de l'évènement. 
	 */
	public void setLieuEvenement(String lieuEvenement) {
		this.lieuEvenement = lieuEvenement;
	}

	/**
    Lire la date d'un évènement. 
    @return La date de l'évènement. 
	 */
	public LocalDate getDateEvenement() {
		return dateEvenement;
	}

	/**
    Alterer la date d'un évènement.
    @param dateEvenement La date de l'évènement. 
	 */
	public void setDateEvenement(LocalDate dateEvenement) {
		this.dateEvenement = dateEvenement;
	}

	/**
    Lire la catégorie d'un évènement. 
    @return La catégorie de l'évènement. 
	 */
	public Categorie getCategorie() {
		return categorie;
	}

	/**
    Alterer la catégorie d'un évènement. 
    @param categorie La catégorie de l'évènement. 
	 */
	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}

	/**
    Lire la description d'un évènement.. 
    @return La description d'un évènement. 
	 */
	public String getDescriptionEvenement() {
		return descriptionEvenement;
	}

	/**
    Alterer la description d'un évènement.
    @param descriptionEvenement La description de l'évènement. 
	 */
	public void setDescriptionEvenement(String descriptionEvenement) {
		this.descriptionEvenement = descriptionEvenement;
	}

	
	
	
}
