package hei.projet.entities;

import java.sql.Date;

public class Video {

	private Integer id;
	private Evenement evenement;
	private String description;

	
	
	
	
	
	public Video(Integer id, Evenement evenement, String description) {
		super();
		this.id = id;
		this.evenement = evenement;
		this.description = description;
		

	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Evenement getEvenement() {
		return evenement;
	}
	public void setEvenement(Evenement evenement) {
		this.evenement = evenement;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}


	

	
	
	


}
