package hei.projet.servlets;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hei.projet.services.VideoService;

@WebServlet("/priveAdmin/videoRecu")
public class VideoRecuServlet extends AbstractGenericServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer videoId = Integer.parseInt(req.getParameter("id"));
		
		Path videoPath = VideoService.getInstance().getVideoPath(videoId);

	Files.copy(videoPath, resp.getOutputStream());

	}
	
	
}
