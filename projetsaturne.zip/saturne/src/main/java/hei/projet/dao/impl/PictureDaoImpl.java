package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.PictureDao;
import hei.projet.entities.Picture;

//Classe qui permet d'accéder et intéragire avec la bdd 

public class PictureDaoImpl implements PictureDao {
	
	/**
    Méthode qui permet de lister les images du site présentent en base selon leur numéro d'identifiant
    @return Liste des images en base.
	 */ 
	@Override
	public List<Picture> listPictures() {
		String query = "SELECT * FROM picture ORDER BY idPicture";
		List<Picture> pictures = new ArrayList<>(); 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Picture picture = new Picture(resultSet.getInt("idPicture"));
						pictures.add(picture);
					}
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pictures;
	}
	
	/**
   	Modifier une image d'une site.
    @param id Le numéro d'identifiant unique en base de l'image à modifier.
    @param pathPicture Le nouveau chemin de l'image.
	 */
	@Override
	public void updatePicture(Integer id, String pathPicture) {
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("UPDATE picture SET pictureSite=? WHERE idPicture= ? ")){
				statement.setString(1, pathPicture);
				statement.setInt(2, id);
				statement.executeUpdate();
				} catch (SQLException e) {
					e.printStackTrace();
					
				}
			}
	
	/**
    Récuperer le chemin en base d'une image
    @param id L'identifiant de l'image
    @return Le chemin en base de l'image correspondant à l'id spécifié. 
	 */
	@Override
	public String getPicturePath(Integer id) {
		
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT pictureSite FROM picture WHERE idPicture = ?")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return resultSet.getString("pictureSite");
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;	
	}

}
