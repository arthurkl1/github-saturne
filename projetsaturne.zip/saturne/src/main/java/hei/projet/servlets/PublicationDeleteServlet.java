package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.services.PublicationService;

@WebServlet("/priveAdmin/deletepublication")
public class PublicationDeleteServlet extends AbstractGenericServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String confirm = req.getParameter("confirm");
		Integer idPublication = Integer.parseInt(req.getParameter("id"));
		if ("true".equals(confirm)){
			PublicationService.getInstance().removePublication(idPublication);
			resp.sendRedirect("admingestionvideos");
			
		}else{
					
			TemplateEngine templateEngine = this.createTemplateEngine(req);
		
			WebContext context = new WebContext(req,resp, req.getServletContext());
		
			
			context.setVariable("publication", PublicationService.getInstance().getPublication(idPublication));
		
			templateEngine.process("confirmdeletepublication", context, resp.getWriter());
		
		}
		
	}
	
	

}
