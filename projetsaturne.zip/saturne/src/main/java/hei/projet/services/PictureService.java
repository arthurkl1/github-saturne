package hei.projet.services;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.Part;

import hei.projet.dao.impl.PictureDaoImpl;
import hei.projet.entities.Picture;

public class PictureService {
	
	private PictureDaoImpl pictureDao = new PictureDaoImpl();
	//Permet d'avoir notre référence = chemin de base
	private static final String PICTURE_MAIN_DIRECTORY = "/app/data"; //  C:/HEI/data

	private static class PictureServiceHolder{
		private static PictureService instance = new PictureService();
	}
	
	public static PictureService getInstance(){
		return PictureServiceHolder.instance;
	}
	
	private PictureService(){
	}
	
	public List<Picture> listPicture(){
		return pictureDao.listPictures();
	}
	
	public void updatePicture(Integer idPicture, Part picture) throws IOException{
		// si le champ picture est null, on renvoie une exception
		if (picture == null){
			throw new IllegalArgumentException("Saisir une image.");
		}
		//Aller sotcker l'image à un endroit précis du disque dur
		// représente le chemin en file system
		// On ajoute le nom du fichier au chemin de base. 
		Path picturePath = Paths.get(PICTURE_MAIN_DIRECTORY,picture.getSubmittedFileName());
		// on envoie le tout à la requête ( = ajout en bdd) 		
		pictureDao.updatePicture(idPicture,picturePath.toString());
		// il faut aussi ajouter l'image dans le file system
		// on fait donc une copie du contenu de l'inputStream vers un path (= la target). 
		Files.copy(picture.getInputStream(), picturePath);
		
	}
	
	public Path getPicturePath(Integer pictureId){
		String picturePathString = pictureDao.getPicturePath(pictureId);
		if (picturePathString == null){
			return getDefaultPicturePath();
		}else{
			Path picturePath = Paths.get(pictureDao.getPicturePath(pictureId));
			if (Files.exists(picturePath)){
				return picturePath;
			}else{
				return getDefaultPicturePath();
			}
		}
		
	}
	
	private Path getDefaultPicturePath(){
		try {
			return Paths.get(this.getClass().getClassLoader().getResource("logosaturne.PNG").toURI());
		} catch (URISyntaxException e) {
			return null;
		}
	}
	
	
}
