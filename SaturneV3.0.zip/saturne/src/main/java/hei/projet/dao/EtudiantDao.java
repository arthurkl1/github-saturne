package hei.projet.dao;

import java.util.List;

import hei.projet.entities.Etudiant;

public interface EtudiantDao {
	
	public List<Etudiant> listEtudiants();
	
	Etudiant getEtudiant(Integer id);
	
	Etudiant getEtudiantByMail (String mail);
	
	String getMotDePasseEtudiantHashe (String id) ;
	
	void modifierRoleAdmin(Integer id, boolean admin);
	
	void modifierMotDePasse(Integer id, String motDePasse);
	
	public Etudiant addEtudiant(Etudiant newEtudiant, String motDePasse);
	
	public void removeEtudiant(Integer id);

}
