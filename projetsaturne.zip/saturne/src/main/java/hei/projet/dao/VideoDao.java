package hei.projet.dao;

import java.util.List;

import hei.projet.entities.Video;

public interface VideoDao {

	public void addVideo (Video newVideo, String linkVideo);
	
	public List<Video> listVideos();
	
	public Video getVideo(Integer id);
	
	public void removeVideo(Integer id);
	
	public String getVideoPath (Integer id) ;
}
