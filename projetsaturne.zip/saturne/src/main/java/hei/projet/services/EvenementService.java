package hei.projet.services;

import java.util.List;

import hei.projet.dao.EvenementDao;
import hei.projet.dao.impl.EvenementDaoImpl;
import hei.projet.entities.Evenement;
import hei.projet.entities.Publication;


public class EvenementService {

	private EvenementDao evenementDao = new EvenementDaoImpl();
	

	private static class EvenementServiceHolder{
		private static EvenementService instance = new EvenementService();
	}
	
	public static  EvenementService getInstance(){
		return EvenementServiceHolder.instance;
	}
	
	private EvenementService(){
	}
	
	public List<Evenement> listEvenement(){
		return evenementDao.listEvenements();
	}
	
	public Evenement getCategorie(Integer id){
		return evenementDao.getEvenement(id);
	
	}
	
	public Evenement getEvenement(Integer id){
		return evenementDao.getEvenement(id);
	}
	
	public Evenement addEvenement(Evenement evenement){
		evenementDao.addEvenement(evenement);
		return evenement;
	}
	
	public void removeEvenement(Integer id){
		if (id == null){
			throw new IllegalArgumentException("L'id de la publication doit être donné");
		}
		evenementDao.removeEvenement(id);
	}
	
	
}
