package hei.projet.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.exceptions.SaturneSecuriteException;
import hei.projet.services.EtudiantService;
import hei.projet.utils.MotDePasseUtils;


@WebServlet("/authentificationAdmin")
public class ConnexionAdminServlet extends GenericSaturneServlet {
	
	private static final long serialVersionUID = -3032812618526895052L;
	//private Map<String, String> utilisateurAdminAutorise;
	
	
	MotDePasseUtils motDePasseUtils = new MotDePasseUtils();
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		
		
		
		
		
		if (req.getSession().getAttribute("utilisateurAdminConnecte") == null){
			TemplateEngine templateEngine = this.createTemplateEngine(req);
			WebContext context = new WebContext(req, resp, req.getServletContext());
			templateEngine.process("connexionAdmin", context, resp.getWriter());
		
		
		}else{
			TemplateEngine templateEngine = this.createTemplateEngine(req);
			WebContext context = new WebContext(req, resp, req.getServletContext());
			templateEngine.process("connexionAdmin2", context, resp.getWriter());
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				
		String email = req.getParameter("email");
		String motDePasse = req.getParameter("password");
		
		try {
			if (EtudiantService.getInstance().validerMotDePasse(email, motDePasse)
					&& EtudiantService.getInstance().getEtudiantByMail(email).isAdmin()){
				req.getSession().setAttribute("utilisateurAdminConnecte", EtudiantService.getInstance().getEtudiantByMail(email)); 
			}else{
				this.ajouterMessageErreur(req, "Le mot de passe renseigné est faux.");
			}
			} catch (IllegalArgumentException e) {
				this.ajouterMessageErreur(req, e.getMessage());
			} catch (SaturneSecuriteException e) {
				this.ajouterMessageErreur(req, "Problème à la vérification du mot de passe.");
			}
		resp.sendRedirect("authentificationAdmin");
	}
	}



