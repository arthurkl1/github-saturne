package hei.projet.dao.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import hei.projet.dao.CategorieDao;
import hei.projet.entities.Categorie;

public class CategorieDaoImpl implements CategorieDao{

	@Override
	public List<Categorie> listCategories() {
		String query = "SELECT * FROM categorie WHERE deletedCategorie = false ORDER BY titreCategorie";
		List<Categorie> categories = new ArrayList<>(); 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Categorie categorie = new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
						categories.add(categorie);
					}
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return categories;
		
	}

	@Override
	public Categorie getCategorie(Integer id) {	
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM categorie WHERE idCategorie = ? AND deletedCategorie=false")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Categorie addCategorie(String nom, String picturePath) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("INSERT INTO categorie(titreCategorie, pictureCategorie) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS)) {
				statement.setString(1, nom);
				statement.setString(2, picturePath);
				statement.executeUpdate();
				
				try (ResultSet resultSet = statement.getGeneratedKeys()) {
					if(resultSet.next()) {
						return new Categorie(resultSet.getInt(1), nom, picturePath);
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void removeCategorie(Integer id){
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("UPDATE categorie SET deletedCategorie=true WHERE idCategorie=?")
						){
			statement.setInt(1,id);
			statement.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
			
		}

	@Override
	public String getPicturePath(Integer id) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT pictureCategorie FROM categorie WHERE idCategorie = ? AND deletedCategorie=false")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return resultSet.getString("pictureCategorie");
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	}
