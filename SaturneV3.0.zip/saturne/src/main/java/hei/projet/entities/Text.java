package hei.projet.entities;

public class Text {

	private Integer id;
	private String contenu;
	
	public Text(Integer id, String contenu){
		super();
		this.id = id;
		this.contenu = contenu;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getContenu() {
		return contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

}
