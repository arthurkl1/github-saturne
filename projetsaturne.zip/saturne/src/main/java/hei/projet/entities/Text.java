package hei.projet.entities;

//Cette classe permet de représenter la table texte de la base de données sous forme d'objet Java

public class Text {

	//Attribut de la classe Text
	private Integer id;
	private String contenu;
	
	/**
    Constructeur de la classe Text
    @param id L'id du texte.  
    @param contenu Le contenu du texte. 
	 */
	public Text(Integer id, String contenu){
		super();
		this.id = id;
		this.contenu = contenu;
	}

	/**
    Lire l'identifiant du texte. 
    @return L'identifiant du texte. 
	 */
	public Integer getId() {
		return id;
	}

	/**
    Alterer l'identifiant d'un texte. 
    @param id L'identifiant du texte. 
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
    Lire le contenu du texte. 
    @return Le contenu du texte. 
	 */
	public String getContenu() {
		return contenu;
	}

	/**
    Alterer le contenu du texte. 
    @param contenu Le contenu du texte.  
	 */
	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

}
