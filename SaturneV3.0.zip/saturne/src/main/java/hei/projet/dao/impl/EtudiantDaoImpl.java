package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.EtudiantDao;
import hei.projet.entities.Etudiant;
import hei.projet.exceptions.SaturneSQLException;



public class EtudiantDaoImpl  implements EtudiantDao {

	@Override
	public List<Etudiant> listEtudiants() {
		String query = "SELECT * FROM etudiant WHERE deletedEtudiant = false ORDER BY mailEtudiant ";
		List<Etudiant> etudiants = new ArrayList<>(); 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Etudiant etudiant = new Etudiant(resultSet.getInt("idEtudiant"), resultSet.getString("mailEtudiant"), resultSet.getBoolean("admin"));
						etudiants.add(etudiant);
					}
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return etudiants;
		
	}

	@Override
	public Etudiant getEtudiant(Integer id) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM etudiant WHERE idEtudiant = ?")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return  new Etudiant(resultSet.getInt("idEtudiant"), resultSet.getString("mailEtudiant"), resultSet.getBoolean("admin"));
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	public Etudiant getEtudiantByMail(String email) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM etudiant WHERE mailEtudiant = ?")) {
				statement.setString(1, email);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return  new Etudiant(resultSet.getInt("idEtudiant"), resultSet.getString("mailEtudiant"), resultSet.getBoolean("admin"));
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getMotDePasseEtudiantHashe(String email) {
		String motDePasse = null;
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT mdpEtudiant FROM etudiant WHERE mailEtudiant = ?")) {
				statement.setString(1, email);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						motDePasse = resultSet.getString("mdpEtudiant");
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return motDePasse;
	}
	
	@Override
	public void modifierMotDePasse(Integer id, String mdp){
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("UPDATE etudiant SET mdpEtudiant=? WHERE idEtudiant=?")){
				statement.setString(1, mdp);
				statement.setInt(2, id);
				statement.executeUpdate();
				statement.close();
			}
		}catch (SQLException e) {
	e.printStackTrace();
		}
	} 
	
	
	@Override
	public void modifierRoleAdmin(Integer id, boolean admin){
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("UPDATE etudiant SET admin=? WHERE idEtudiant=?")){
				statement.setBoolean(1, admin);
				statement.setInt(2, id);
				statement.executeUpdate();
				statement.close();
			}
		}catch (SQLException e) {
	e.printStackTrace();
		}
	} 
	

		
	
	

	@Override
	public Etudiant addEtudiant(Etudiant etudiant, String motDePasse)  {
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("INSERT INTO Etudiant(mailEtudiant,mdpEtudiant) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS)
						){
			statement.setString(1,etudiant.getEmail());
			statement.setString(2, motDePasse);
			statement.executeUpdate();
			try (ResultSet resultSet = statement.getGeneratedKeys()) {
				if(resultSet.next()) {
					etudiant.setId(resultSet.getInt(1));
				}
			}
		}catch (SQLException e) {
			throw new SaturneSQLException(e);
		}
		return etudiant;
	}
	
	public void removeEtudiant(Integer id){
	try(Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement statement = connection.prepareStatement("UPDATE etudiant SET deletedEtudiant=true WHERE idEtudiant=?")
					){
		statement.setInt(1,id);
		statement.executeUpdate();
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}
}

	


