package hei.projet.services;

import java.io.IOException;
import java.util.List;

import hei.projet.dao.impl.TextDaoImpl;
import hei.projet.entities.Text;


public class TextService {
	
	private TextDaoImpl textDao = new TextDaoImpl();
	
	private static class TextServiceHolder{
		private static TextService instance = new TextService();
	}
		
	public static TextService getInstance(){
		return TextServiceHolder.instance;
	}
	
	public List<Text> listText(){
		return textDao.listTexts();
	}
	
	public void updateText(Integer idText, String contenu) throws IOException {
		textDao.updateText(idText, contenu);
	}

}
