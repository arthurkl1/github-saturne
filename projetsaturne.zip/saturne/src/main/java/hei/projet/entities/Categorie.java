package hei.projet.entities;

//Cette classe permet de représenter la table categorie de la base de données sous forme d'objet Java

public class Categorie {
	
	//Attribut de la classe Catégorie
	private Integer id;
	private String nom;
	private String localisation;
	

	/**
    Constructeur de la classe Catégorie
    @param id L'id de la catégorie.  
    @param nom Le nom de la catégorie. 
    @param localisation Le chemin de l'image de la catégorie.  
	 */
	public Categorie(Integer id, String nom, String localisation){
		super();
		this.id = id;
		this.nom = nom;
		this.localisation=localisation;
	}
	
	/**
    Lire l'identifiant d'une catégorie. 
    @return L'identifiant d'une catégorie. 
	 */
	public Integer getId() {
		return id;
	}
	
	/**
    Alterer l'identifiant d'une catégorie
    @param id L'identifiant de la catégorie. 
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
    Lire le nom d'une catégorie. 
    @return Le nom d'une catégorie. 
	 */
	public String getNom() {
		return nom;
	}
	
	/**
    Alterer le nom d'une catégorie
    @param id Le nom de la catégorie. 
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/**
    Lire le chemin en base de l'image d'une catégorie. 
    @return Le chemin en base de l'image d'une catégorie. 
	 */
	public String getLocalisation() {
		return localisation;
	}
	
	/**
    Alterer le chemin en base de l'image d'une catégorie
    @param localisation Le chemin en base de l'image d'une catégorie. 
	 */
	public void setLocalisation(String localisation) {
		this.localisation = localisation;
	}
	
	
	

}
