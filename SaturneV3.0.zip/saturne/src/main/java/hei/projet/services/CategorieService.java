package hei.projet.services;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.Part;

import hei.projet.dao.impl.CategorieDaoImpl;
import hei.projet.entities.Categorie;


public class CategorieService {

	private CategorieDaoImpl categorieDao = new CategorieDaoImpl();
	
	private static final String PICTURE_MAIN_DIRECTORY = "/app/data"; //  C:/HEI/data
	
	private static class CatogrieServiceHolder{
		private static CategorieService instance = new CategorieService();
	}
	
	public static CategorieService getInstance(){
		return CatogrieServiceHolder.instance;
	}
	
	private CategorieService(){
	}
	
	public List<Categorie> listCategorie(){
		return categorieDao.listCategories();
	}
	
	public Categorie getCategorie(Integer id){
		return categorieDao.getCategorie(id);
	
	}
	
	public void addCategorie(String nom, Part picture) throws IOException{
		if (picture == null){
			throw new IllegalArgumentException("Une catégorie doit avoir une image.");
		}
		
		//Aller sotcker l'image à un endroit précis du disque dur
		Path picturePath = Paths.get(PICTURE_MAIN_DIRECTORY,picture.getSubmittedFileName());
				
		categorieDao.addCategorie(nom,picturePath.toString());
		
		Files.copy(picture.getInputStream(), picturePath);
		
	}
	
	public Path getPicturePath(Integer categorieId){
		String picturePathString = categorieDao.getPicturePath(categorieId);
		if (picturePathString == null){
			return getDefaultPicturePath();
		}else{
			Path picturePath = Paths.get(categorieDao.getPicturePath(categorieId));
			if (Files.exists(picturePath)){
				return picturePath;
			}else{
				return getDefaultPicturePath();
			}
		}
		
	}
	
	private Path getDefaultPicturePath(){
		try {
			return Paths.get(this.getClass().getClassLoader().getResource("logosaturne.PNG").toURI());
		} catch (URISyntaxException e) {
			return null;
		}
	}
	
	public void removeCategorie(Integer id){
		
		if (id == null){
			throw new IllegalArgumentException("L'id de la publication doit être donné");
		}
		categorieDao.removeCategorie(id);
	}

}
