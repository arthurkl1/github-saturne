package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.entities.Evenement;
import hei.projet.entities.Video;
import hei.projet.services.CategorieService;
import hei.projet.services.EvenementService;
import hei.projet.services.PublicationService;
import hei.projet.services.VideoService;

@WebServlet("/prive/addVideo")
@MultipartConfig
public class AddVideoServlet extends AbstractGenericServlet {

	

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			
		Integer evenementId = Integer.parseInt(req.getParameter("event"));
		Evenement evenement = EvenementService.getInstance().getEvenement(evenementId);
		
		Part lienVideo = req.getPart("videoEtudiant");
		String descriptionVideo = req.getParameter("descriptionVideo");
		
		
		
		Video newVideo = new Video(null, evenement, descriptionVideo);
			
	
			
			try{
				VideoService.getInstance().addVideo( newVideo, lienVideo);
				resp.sendRedirect("accueil");
			}catch(IOException e){
				req.getSession().setAttribute("videoCreationErreur", e.getMessage());
			}
			}
			
			
		}