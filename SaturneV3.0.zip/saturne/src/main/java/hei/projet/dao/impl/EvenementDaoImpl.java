package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.EvenementDao;
import hei.projet.entities.Categorie;
import hei.projet.entities.Evenement;


public class EvenementDaoImpl implements EvenementDao {

	@Override
	public List<Evenement> listEvenements() {
		String query = "SELECT * FROM evenement JOIN categorie ON evenement.idCategorie = categorie.idCategorie WHERE deletedEvenement = false ORDER BY dateEvenement ASC";
		List<Evenement> evenements = new ArrayList<>(); 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Categorie categorie = new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
						Evenement evenement = new Evenement(resultSet.getInt("idEvenement"), resultSet.getString("titreEvenement"),
								resultSet.getString("lieuEvenement"),resultSet.getDate("dateEvenement").toLocalDate(),categorie, resultSet.getString("descriptionEvent"));
						evenements.add(evenement);
					}
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return evenements;
	}

	@Override
	public Evenement getEvenement(Integer id) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM evenement JOIN categorie ON evenement.idCategorie = categorie.idCategorie WHERE idEvenement = ? AND deletedEvenement=false")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						Categorie categorie = new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
						return new Evenement(resultSet.getInt("idEvenement"), resultSet.getString("titreEvenement"), resultSet.getString("lieuEvenement"),resultSet.getDate("dateEvenement").toLocalDate(),categorie,resultSet.getString("descriptionEvent"));
					}

				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		}
	

	@Override
	public Evenement addEvenement(Evenement evenement) {
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("INSERT INTO evenement(titreEvenement, lieuEvenement, dateEvenement, idCategorie, descriptionEvent) VALUES(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)
						){
			statement.setString(1, evenement.getTitleEvenement());
			statement.setString(2, evenement.getLieuEvenement());
			statement.setDate(3, Date.valueOf(evenement.getDateEvenement()));
			statement.setInt(4, evenement.getCategorie().getId());
			statement.setString(5, evenement.getDescriptionEvenement());
			statement.executeUpdate();
			
			try (ResultSet resultSet = statement.getGeneratedKeys()) {
				if(resultSet.next()) {
					evenement.setIdEvenement(resultSet.getInt(1));
				}return evenement;
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public void removeEvenement(Integer idEvenement){
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("UPDATE evenement SET deletedEvenement=true WHERE idEvenement=?")
						){
			statement.setInt(1,idEvenement);
			statement.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
			
		}

	

}
