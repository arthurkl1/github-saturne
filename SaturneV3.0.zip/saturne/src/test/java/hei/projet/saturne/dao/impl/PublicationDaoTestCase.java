package hei.projet.saturne.dao.impl;

import static org.assertj.core.api.Assertions.assertThat;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;


import hei.projet.dao.PublicationDao;

import hei.projet.dao.impl.DataSourceProvider;
import hei.projet.dao.impl.PublicationDaoImpl;
import hei.projet.entities.Categorie;
import hei.projet.entities.Publication;


public class PublicationDaoTestCase {
	private PublicationDao publicationDao = new PublicationDaoImpl();

	@Before
	public void initDb() throws Exception {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate("DELETE FROM publication");
			//stmt.executeUpdate("DELETE FROM categorie");
			//stmt.executeUpdate("INSERT INTO `categorie`(`idCategorie`,`titreCategorie`) VALUES (1,'Administration')");
			//stmt.executeUpdate("INSERT INTO `categorie`(`idCategorie`,`titreCategorie`) VALUES (2,'BDA')");
			stmt.executeUpdate(
					"INSERT INTO `publication`(`idPublication`,`titrePublication`, datePublication, lienPublication, idCategorie, deletedPublication) "
							+ "VALUES (1, 'Titre1', '2017-04-16', 'https://www.youtube.com/watch?v=QQXZKZuJ-KE',1, false)");
			stmt.executeUpdate(
					"INSERT INTO `publication`(`idPublication`,`titrePublication`, datePublication, lienPublication, idCategorie, deletedPublication) "
							+ "VALUES (2, 'Titre2', '2017-05-16', 'https://www.youtube.com/watch?v=PpFEZQ28RoA',2,true)");
		}
	}

	@Test
	public void shouldListPublication() {
		// WHEN
		List<Publication> publications = publicationDao.listPublications();
		// THEN
		Assertions.assertThat(publications).hasSize(1);
		Assertions.assertThat(publications).extracting("id", "titre", "releaseDate", "lienYouTube", "categorie.id", "categorie.nom").containsOnly(
			Assertions.tuple(1, "Titre1", LocalDate.of(2017, 04, 16), "https://www.youtube.com/watch?v=QQXZKZuJ-KE",1, "Administration")//,
			//Assertions.tuple(2, "Titre2", LocalDate.of(2017, 05, 16), "https://www.youtube.com/watch?v=PpFEZQ28RoA", 2, "BDA")
		);

	}

	@Test
	public void shouldGetPublication() {
		// WHEN
		Publication publication = publicationDao.getPublication(1);
		// THEN
		Assertions.assertThat(publication).isNotNull();
		Assertions.assertThat(publication.getId()).isEqualTo(1);
		Assertions.assertThat(publication.getTitre()).isEqualTo("Titre1");
		Assertions.assertThat(publication.getReleaseDate()).isEqualTo(LocalDate.of(2017, 04, 16));
		Assertions.assertThat(publication.getLienYouTube()).isEqualTo("https://www.youtube.com/watch?v=QQXZKZuJ-KE");
		Assertions.assertThat(publication.getCategorie().getId()).isEqualTo(1);
		Assertions.assertThat(publication.getCategorie().getNom()).isEqualTo("Administration");
	}
	
	@Test
	public void shouldNotGetPublication() {
		// WHEN
		Publication publication = publicationDao.getPublication(2);
		// THEN
		Assertions.assertThat(publication).isNull();
	}

	@Test
	public void shouldAddPublication() throws Exception {
		// GIVEN
		Publication publicationToAdd = new Publication(null, "New title", LocalDate.of(2017, 06, 16), "https://www.youtube.com/watch?v=_hh07JN59v4",  new Categorie(1, "Administration","BDE.jpg"));
		// WHEN
		Publication publicationAdded = publicationDao.addPublication(publicationToAdd);
		// THEN
		Assertions.assertThat(publicationAdded).isNotNull();
		Assertions.assertThat(publicationAdded.getId()).isNotNull();
		Assertions.assertThat(publicationAdded.getTitre()).isEqualTo("New title");
		Assertions.assertThat(publicationAdded.getReleaseDate()).isEqualTo(LocalDate.of(2017, 06, 16));
		Assertions.assertThat(publicationAdded.getLienYouTube()).isEqualTo("https://www.youtube.com/watch?v=_hh07JN59v4");
		Assertions.assertThat(publicationAdded.getCategorie().getId()).isEqualTo(1);
		Assertions.assertThat(publicationAdded.getCategorie().getNom()).isEqualTo("Administration");
		
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("SELECT * FROM publication WHERE idPublication = ?")) {
			stmt.setInt(1, publicationAdded.getId());
			try (ResultSet rs = stmt.executeQuery()) {
				assertThat(rs.next()).isTrue();
				assertThat(rs.getInt("idPublication")).isEqualTo(publicationAdded.getId());
				assertThat(rs.getString("titrePublication")).isEqualTo("New title");
				assertThat(rs.getDate("datePublication").toLocalDate()).isEqualTo(LocalDate.of(2017, 06, 16));
				assertThat(rs.getString("lienPublication")).isEqualTo("https://www.youtube.com/watch?v=_hh07JN59v4");
				assertThat(rs.getInt("idCategorie")).isEqualTo(1);
				assertThat(rs.next()).isFalse();
			}
		}
		
	}
	
	@Test 
	public void shouldDeletePublication() throws Exception{
		//WHEN
		publicationDao.removePublication(1);
		//THEN 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM publication WHERE idPublication=1")) {
			Assertions.assertThat(resultSet.next()).isTrue();
			assertThat(resultSet.getInt("idPublication")).isNotNull();
			assertThat(resultSet.getString("titrePublication")).isEqualTo("Titre1");
			assertThat(resultSet.getDate("datePublication").toLocalDate()).isEqualTo(LocalDate.of(2017, 04, 16));
			assertThat(resultSet.getString("lienPublication")).isEqualTo("https://www.youtube.com/watch?v=QQXZKZuJ-KE");
			assertThat(resultSet.getInt("idCategorie")).isEqualTo(1);
			assertThat(resultSet.getBoolean("deletedPublication")).isTrue();
			assertThat(resultSet.next()).isFalse();			
		}
	}
}