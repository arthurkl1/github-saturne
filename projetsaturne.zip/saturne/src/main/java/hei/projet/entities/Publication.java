package hei.projet.entities;


import java.time.LocalDate;

//Cette classe permet de représenter la table publication de la base de données sous forme d'objet Java

public class Publication {
	
	//Attribut de la classe Publication
	private Integer id;
	private String titre;
	private LocalDate releaseDate;
	private String lienYouTube;
	private Categorie categorie;
	
	/**
    Constructeur de la classe Publication
    @param id L'id de la publication.  
    @param title Le titre de la publication. 
    @param releaseDate La date de l'evenement.
    @param dateEvenement La date  de la publication.
    @param lieuYoutube Le lien youtube de la publication.
     @param categorie La categorie à laquelle appartient la publication.
	 */
	public Publication(Integer id, String titre, LocalDate releaseDate,
			String lienYouTube, Categorie categorie){
		super();
		this.id = id;
		this.titre = titre;
		this.releaseDate = releaseDate;
		this.lienYouTube = lienYouTube; 
		this.categorie = categorie;
		}

	
	/**
    Lire l'identifiant d'une publication. 
    @return L'identifiant d'une publication. 
	 */
	public Integer getId() {
		return id;
	}

	/**
    Alterer l'id d'une publication. 
    @param id L'id de la publication. 
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
    Lire le titre d'une publication. 
    @return Le titre d'une publication. 
	 */
	public String getTitre() {
		return titre;
	}

	/**
    Alterer le titre d'une publication. 
    @param title le titre de la publication. 
	 */
	public void setTitre(String title) {
		this.titre = title;
	}

	/**
    Lire la date d'une publication. 
    @return La date d'une publciationt. 
	 */
	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	/**
    Alterer la date d'une publication. 
    @param releaseDate La date de la publication. 
	 */
	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}

	/**
    Lire le lien youtuve d'une publication. 
    @return Le lien youtube d'une publication. 
	 */
	public String getLienYouTube() {
		return lienYouTube;
	}

	/**
    Alterer le lien youtube d'une publication. 
    @param lienYouTube Le lien youtube d'une publication. 
	 */
	public void setLienYouTube(String lienYouTube) {
		this.lienYouTube = lienYouTube;
	}

	/**
    Lire la catégorie d'une publication.  
    @return La catégorie d'une publication. 
	 */
	public Categorie getCategorie() {
		return categorie;
	}

	/**
    Alterer la catégorie à laquelle appartient une publication. 
    @param categorie La catégorie de la publication. 
	 */
	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}

}
