package hei.projet.exceptions;

public class SaturneAccesException extends Exception {
	
	private static final long serialVersionUID = 7348054554643258527L;

	public SaturneAccesException() {
		super();
	}

	public SaturneAccesException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SaturneAccesException(String message, Throwable cause) {
		super(message, cause);
	}

	public SaturneAccesException(String message) {
		super(message);
	}

	public SaturneAccesException(Throwable cause) {
		super(cause);
	}

}
