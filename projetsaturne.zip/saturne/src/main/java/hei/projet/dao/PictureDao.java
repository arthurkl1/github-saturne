package hei.projet.dao;

import java.util.List;

import hei.projet.entities.Picture;

public interface PictureDao {
	
	public List<Picture> listPictures();
	
	public void updatePicture (Integer id, String pathPicture);
	
	public String getPicturePath (Integer id) ;

}
