package hei.projet.exceptions;

public class SaturneSQLException extends RuntimeException {
	
	private static final long serialVersionUID = 8520858908301006744L;

	public SaturneSQLException() {
		super();
	}

	public SaturneSQLException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SaturneSQLException(String message, Throwable cause) {
		super(message, cause);
	}

	public SaturneSQLException(String message) {
		super(message);
	}

	public SaturneSQLException(Throwable cause) {
		super(cause);
	}

}
