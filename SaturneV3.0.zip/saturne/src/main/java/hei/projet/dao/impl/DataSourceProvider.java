package hei.projet.dao.impl;

import javax.sql.DataSource;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class DataSourceProvider {
	
	private static MysqlDataSource dataSource;

	/*public static DataSource getDataSource() {
		if (dataSource == null) {
			dataSource = new MysqlDataSource();
			dataSource.setServerName("byxg2ky6b-mysql.services.clever-cloud.com");
			dataSource.setPort(3306);
			dataSource.setDatabaseName("byxg2ky6b"); //A changer nom schema
			dataSource.setUser("uqh4tdhfsua6u3pj");//A changer
			dataSource.setPassword("WxMam850FJfWSz5HkI6");//A changer pour adri :0000 /// pour arthur : hei2016-2017
		}
		return dataSource;
	} */

	
	public static DataSource getDataSource() {
		if (dataSource == null) {
			dataSource = new MysqlDataSource();
			dataSource.setServerName("localhost");
			dataSource.setPort(3306);
			dataSource.setDatabaseName("saturne");// A changer nom schema
			dataSource.setUser("root");//A changer
			dataSource.setPassword("hei2016-2017");//A changer pour adri :0000  pour arthur : hei2016-2017
		}
		return dataSource;
	}

}
