package hei.projet.saturne.dao.impl;

import static org.assertj.core.api.Assertions.assertThat;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;


import hei.projet.dao.EvenementDao;

import hei.projet.dao.impl.DataSourceProvider;
import hei.projet.dao.impl.EvenementDaoImpl;
import hei.projet.entities.Categorie;
import hei.projet.entities.Evenement;


public class EvenementDaoTestCase {
	private EvenementDao evenementDao = new EvenementDaoImpl();

	@Before
	public void initDb() throws Exception {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate("DELETE FROM evenement");
			stmt.executeUpdate(
					"INSERT INTO `evenement`(`idEvenement`,`titreEvenement`, lieuEvenement, dateEvenement, idCategorie, deletedEvenement, `descriptionEvent`) "
							+ "VALUES (1, 'Titre1', 'HEI', '2017-04-16',1, false, 'blablablablablablabalablaalbaa')");
			stmt.executeUpdate(
					"INSERT INTO `evenement`(`idEvenement`,`titreEvenement`, lieuEvenement, dateEvenement, idCategorie, deletedEvenement, `descriptionEvent`) "
							+ "VALUES (2, 'Titre2', 'Saint pierre', '2017-05-16',2,true, 'blablablablabla')");
		}
	}

	@Test
	public void shouldListEvenement() {
		// WHEN
		List<Evenement> evenements = evenementDao.listEvenements();
		// THEN
		Assertions.assertThat(evenements).hasSize(1);
		Assertions.assertThat(evenements).extracting("idEvenement", "titleEvenement", "lieuEvenement", "dateEvenement", "categorie.id", "categorie.nom", "descriptionEvenement").containsOnly(
			Assertions.tuple(1, "Titre1", "HEI",LocalDate.of(2017, 04, 16),1, "Administration","blablablablablablabalablaalbaa")//,
			//Assertions.tuple(2, "Titre2", "Saint pierre", LocalDate.of(2017, 05, 16), 2, "BDA")
		);

	}

	@Test
	public void shouldGetEvenement() {
		// WHEN
		Evenement evenement = evenementDao.getEvenement(1);
		// THEN
		Assertions.assertThat(evenement).isNotNull();
		Assertions.assertThat(evenement.getIdEvenement()).isEqualTo(1);
		Assertions.assertThat(evenement.getTitleEvenement()).isEqualTo("Titre1");
		Assertions.assertThat(evenement.getLieuEvenement()).isEqualTo("HEI");
		Assertions.assertThat(evenement.getDateEvenement()).isEqualTo(LocalDate.of(2017, 04, 16));
		Assertions.assertThat(evenement.getCategorie().getId()).isEqualTo(1);
		Assertions.assertThat(evenement.getCategorie().getNom()).isEqualTo("Administration");
		Assertions.assertThat(evenement.getDescriptionEvenement()).isEqualTo("blablablablablablabalablaalbaa");
	}
	
	@Test
	public void shouldNotGetEvenement() {
		// WHEN
		Evenement evenement = evenementDao.getEvenement(2);
		// THEN
		Assertions.assertThat(evenement).isNull();
	}

	@Test
	public void shouldAddEvenement() throws Exception {
		// GIVEN
		Evenement evenementToAdd = new Evenement(null, "New title",  "Toul", LocalDate.of(2017, 06, 16),  new Categorie(1, "Administration","BDE.jpg"), "blablablablablablabalablaalbaa");
		// WHEN
		Evenement evenementAdded = evenementDao.addEvenement(evenementToAdd);
		// THEN
		Assertions.assertThat(evenementAdded).isNotNull();
		Assertions.assertThat(evenementAdded.getIdEvenement()).isNotNull();
		Assertions.assertThat(evenementAdded.getTitleEvenement()).isEqualTo("New title");
		Assertions.assertThat(evenementAdded.getLieuEvenement()).isEqualTo("Toul");
		Assertions.assertThat(evenementAdded.getDateEvenement()).isEqualTo(LocalDate.of(2017, 06, 16));
		Assertions.assertThat(evenementAdded.getCategorie().getId()).isEqualTo(1);
		Assertions.assertThat(evenementAdded.getCategorie().getNom()).isEqualTo("Administration");
		Assertions.assertThat(evenementAdded.getDescriptionEvenement()).isEqualTo("blablablablablablabalablaalbaa");
		
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("SELECT * FROM evenement WHERE idEvenement = ?")) {
			stmt.setInt(1, evenementAdded.getIdEvenement());
			try (ResultSet rs = stmt.executeQuery()) {
				assertThat(rs.next()).isTrue();
				assertThat(rs.getInt("idEvenement")).isEqualTo(evenementAdded.getIdEvenement());
				assertThat(rs.getString("titreEvenement")).isEqualTo("New title");
				assertThat(rs.getString("lieuEvenement")).isEqualTo("Toul");
				assertThat(rs.getDate("dateEvenement").toLocalDate()).isEqualTo(LocalDate.of(2017, 06, 16));
				assertThat(rs.getInt("idCategorie")).isEqualTo(1);
				assertThat(rs.getBoolean("deletedEvenement")).isFalse();
				assertThat(rs.getString("descriptionEvent")).isEqualTo("blablablablablablabalablaalbaa");
				assertThat(rs.next()).isFalse();
			}
		}
		
	}
	
	@Test 
	public void shouldDeleteEvenement() throws Exception{
		//WHEN
		evenementDao.removeEvenement(1);
		//THEN 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM evenement WHERE idEvenement=1")) {
			Assertions.assertThat(resultSet.next()).isTrue();
			assertThat(resultSet.getInt("idEvenement")).isNotNull();
			assertThat(resultSet.getString("titreEvenement")).isEqualTo("Titre1");
			assertThat(resultSet.getString("lieuEvenement")).isEqualTo("HEI");
			assertThat(resultSet.getDate("dateEvenement").toLocalDate()).isEqualTo(LocalDate.of(2017, 04, 16));	
			assertThat(resultSet.getInt("idCategorie")).isEqualTo(1);
			assertThat(resultSet.getBoolean("deletedEvenement")).isTrue();
			assertThat(resultSet.getString("descriptionEvent")).isEqualTo("blablablablablablabalablaalbaa");
			assertThat(resultSet.next()).isFalse();
		}
	}
}