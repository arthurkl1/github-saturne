package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/prive/deconnexion") // Mapping vers /prive/deconnexion
public class DeconnexionServlet extends HttpServlet {
	
	private static final long serialVersionUID = -3032812618526895052L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Récuprer la session et supprimé l'attribut de l'utilisateur connecté
		req.getSession().removeAttribute("utilisateurConnecte");
		//on redirige vers la page de connexion (authentification)
		resp.sendRedirect("authentification");
	}
	

}
