package hei.projet.entities;

public class Etudiant {
	
		private Integer id;
		private String email;
		private boolean admin;
		
		
		public Etudiant(Integer id, String email, boolean admin){
			super();
			this.id = id;
			this.email = email;
			this.setAdmin(admin);
		}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public boolean isAdmin() {
			return admin;
		}

		public void setAdmin(boolean admin) {
			this.admin = admin;
		}
		
}
