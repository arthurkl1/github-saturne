package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.services.VideoService;

@WebServlet("/priveAdmin/deleteVideo")
public class VideoDeleteServlet extends AbstractGenericServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String confirm = req.getParameter("confirm");
		Integer idVideo = Integer.parseInt(req.getParameter("id"));
		System.out.println(req.getParameter("id"));
		if("true".equals(confirm)){
			VideoService.getInstance().removeVideo(idVideo);
			resp.sendRedirect("admingestionsitevideorecu");
		}
	else{
		
	
	TemplateEngine templateEngine = this.createTemplateEngine(req);
	
	WebContext context = new WebContext(req,resp, req.getServletContext());
	
	context.setVariable("video", VideoService.getInstance().getVideo(idVideo));
	
	templateEngine.process("confirmdeleteVideo", context, resp.getWriter());

	}


}
}
