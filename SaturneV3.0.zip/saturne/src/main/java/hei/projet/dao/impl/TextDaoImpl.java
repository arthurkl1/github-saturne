package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.TextDao;
import hei.projet.entities.Text;

public class TextDaoImpl implements TextDao {

	@Override
	public List<Text> listTexts() {
			String query = "SELECT * FROM text ORDER BY idText";
			List<Text> texts = new ArrayList<>(); 
			try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
				try (Statement statement = connection.createStatement()) {
					try (ResultSet resultSet = statement.executeQuery(query)) {
						while(resultSet.next()) {
							Text text = new Text(resultSet.getInt("idText"), resultSet.getString("textSite"));
							texts.add(text);
						}
					}
				}			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return texts;
			
		}
	
	

	@Override
	public void updateText(Integer idText, String contenu) {
			try(Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement statement = connection.prepareStatement("UPDATE text SET textSite=? WHERE idText=? ")){
				statement.setString(1, contenu);
				statement.setInt(2, idText);
			statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
		}
		
	}
