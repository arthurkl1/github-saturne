package hei.projet.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.exceptions.SaturneSecuriteException;
import hei.projet.services.EtudiantService;
import hei.projet.utils.MotDePasseUtils;

@WebServlet("/authentification")
public class ConnexionServlet extends GenericSaturneServlet{
	
	private static final long serialVersionUID = -3032812618526895052L;
			
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			
		if (req.getSession().getAttribute("utilisateurConnecte") == null){
			TemplateEngine templateEngine = this.createTemplateEngine(req);
			WebContext context = new WebContext(req, resp, req.getServletContext());
			templateEngine.process("connexion", context, resp.getWriter());
		}else{
			TemplateEngine templateEngine = this.createTemplateEngine(req);
			WebContext context = new WebContext(req, resp, req.getServletContext());
			templateEngine.process("connexion2", context, resp.getWriter());
	
		}
	}

	

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email"); //récupère email dans le formulaire de connexion
		String motDePasse = req.getParameter("password"); // récupère le mdp dans le formulaire de connexion 
		try {
			
			if (EtudiantService.getInstance().validerMotDePasse(email,motDePasse))
					{
				req.getSession().setAttribute("utilisateurConnecte", EtudiantService.getInstance().getEtudiantByMail(email)); 
					}else{
						this.ajouterMessageErreur(req, "Le mot de passe renseigné est faux.");
					}
		} catch (IllegalArgumentException e) {
			this.ajouterMessageErreur(req, e.getMessage());
		} catch (SaturneSecuriteException e) {
			this.ajouterMessageErreur(req, "Problème à la vérification du mot de passe.");
		}


		resp.sendRedirect("authentification");
		
	}
	
}
	
	


