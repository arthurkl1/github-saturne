package hei.projet.services;

import java.util.List;

import javax.servlet.http.Part;

import hei.projet.dao.CategorieDao;
import hei.projet.dao.PublicationDao;
import hei.projet.dao.impl.CategorieDaoImpl;
import hei.projet.dao.impl.PublicationDaoImpl;
import hei.projet.entities.Categorie;
import hei.projet.entities.Publication;

public class PublicationService {
	
	private static class PublicationServiceHolder{
		private static PublicationService instance = new PublicationService();
	}
	
	public static PublicationService getInstance(){
		return PublicationServiceHolder.instance;
	}
	
	//private PublicationDaoImpl publicationDao = new PublicationDaoImpl();
	private PublicationDao publicationDao = new PublicationDaoImpl();
	//
	private CategorieDao categorieDao = new CategorieDaoImpl();
	
	private PublicationService(){	
	}
	
	//public List<Publication> listPublication(){     il y avait pas de S
	public List<Publication> listPublications(){
		return publicationDao.listPublications();
	}
	
	public Publication getPublication(Integer id){
		return publicationDao.getPublication(id);
	}
	
	public Publication addPublication(Publication publication){
		publicationDao.addPublication(publication);
		return publication;
	}
	
	public void removePublication(Integer id){
		if (id == null){
			throw new IllegalArgumentException("L'id de la publication doit être donné");
		}
		publicationDao.removePublication(id);
	}
	
	//Ajout : 
	//
	//
	public List<Categorie> listCategories() {
		return categorieDao.listCategories();
	}

	public Categorie getCategorie(Integer id) {
		return categorieDao.getCategorie(id);
	}

	public Categorie addCategorie(String nom,String picture) {
		return categorieDao.addCategorie(nom, picture);
	}
	
	
}