package hei.projet.entities;

//Cette classe permet de représenter la table picture de la base de données sous forme d'objet Java
// Picture correspond aux images parametrables du site
public class Picture {
	
	//Attribut de la classe Picture
	private Integer id;
	
	/**
    Constructeur de la classe Picture
    @param id L'id de l'image.    
	 */
	public Picture(Integer id){
		super();
		this.id = id;
	}
	
	/**
    Lire l'identifiant d'une picture. 
    @return L'identifiant d'une picture. 
	 */
	public Integer getId() {
		return id;
	}
	
	/**
    Alterer l'identifiant d'une picture
    @param id L'identifiant de la picture. 
	 */
	public void setId(Integer id) {
		this.id = id;
	}

}
