package hei.projet.exceptions;

public class SaturneSecuriteException extends Exception {
	
	private static final long serialVersionUID = 8520858908301006744L;

	public SaturneSecuriteException() {
		super();
	}

	public SaturneSecuriteException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SaturneSecuriteException(String message, Throwable cause) {
		super(message, cause);
	}

	public SaturneSecuriteException(String message) {
		super(message);
	}

	public SaturneSecuriteException(Throwable cause) {
		super(cause);
	}


}
