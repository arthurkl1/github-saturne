package hei.projet.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.Part;

import hei.projet.dao.impl.VideoDaoImpl;
import hei.projet.entities.Evenement;
import hei.projet.entities.Video;


public class VideoService {

private VideoDaoImpl videoDao = new VideoDaoImpl();

private static final String PICTURE_MAIN_DIRECTORY = "/app/data";  // /Users/arthur/Desktop/data C:/HEI/data
	
	private static class VideoServiceHolder{
		private static VideoService instance = new VideoService();
	}
	
	public static VideoService getInstance(){
		return VideoServiceHolder.instance;
	}
	
	private VideoService(){
		
	}

	public List<Video> listVideos(){
		return videoDao.listVideos();
	}
	
	public Video getVideo(Integer id){
		return videoDao.getVideo(id);
	}
	
	public void removeVideo(Integer id){
		if(id == null){
			throw new IllegalArgumentException("L'id de la vidéo doit être donné");
		}
		videoDao.removeVideo(id);
	}
	
	
	
	
	
	
	
	
	
	public void addVideo(Video video, Part newVideo ) throws IOException{
		if (newVideo == null){
			throw new IllegalArgumentException("Il doit y avoir un fichier.");
		}
		
		// Aller sotcker l'image à un endroit précis du disque dur
		
		Path videoPath = Paths.get(PICTURE_MAIN_DIRECTORY,newVideo.getSubmittedFileName());
				
		videoDao.addVideo(video,videoPath.toString());
		
		Files.copy(newVideo.getInputStream(), videoPath);
		
	}
	
	// Récupère le chemin de la vidéo 
	
	public Path getVideoPath(Integer videoId){
		return Paths.get(videoDao.getVideoPath(videoId));
	}
	

}
