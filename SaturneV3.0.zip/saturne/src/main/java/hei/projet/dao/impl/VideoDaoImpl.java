package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import hei.projet.dao.VideoDao;
import hei.projet.entities.Categorie;
import hei.projet.entities.Evenement;
import hei.projet.entities.Video;

public class VideoDaoImpl implements VideoDao {

	@Override
	public void addVideo(Video newVideo, String linkVideo) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("INSERT INTO video(idEvenement,descriptionVideo, lienVideo) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
				statement.setInt(1, newVideo.getEvenement().getIdEvenement());
				statement.setString(2, newVideo.getDescription());
				statement.setString(3, linkVideo);
				statement.executeUpdate();
				
				try (ResultSet resultSet = statement.getGeneratedKeys()) {
					if(resultSet.next()) {
						return;
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return;
	}

	public String getVideoPath(Integer id){
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT lienVideo FROM video WHERE idVideo = ? AND deletedVideo=false")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return resultSet.getString("lienVideo");
					}
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Video> listVideos() {
		String query = "SELECT * FROM  video JOIN evenement ON video.idEvenement = evenement.idEvenement JOIN categorie ON evenement.idCategorie = categorie.idCategorie WHERE deletedVideo=false";
		List<Video> videos = new ArrayList<>();
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try (Statement statement = connection.createStatement()) {
				try (ResultSet resultSet = statement.executeQuery(query)) {
					while(resultSet.next()) {
						Categorie categorie = new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
						Evenement evenement = new Evenement(resultSet.getInt("idEvenement"), resultSet.getString("titreEvenement"),
								resultSet.getString("lieuEvenement"),resultSet.getDate("dateEvenement").toLocalDate(),categorie, resultSet.getString("descriptionEvent"));
						Video video = new Video(resultSet.getInt("idVideo"), evenement, resultSet.getString("descriptionVideo") );
						videos.add(video);
						
					}
				}
			}
		}  catch (SQLException e) {
			e.printStackTrace();
		}
		return videos;
		
				
	}

	@Override
	public Video getVideo(Integer id) {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM video JOIN evenement ON video.idEvenement = evenement.idEvenement JOIN categorie ON evenement.idCategorie = categorie.idCategorie WHERE  idVideo=? AND deletedVideo = false")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						Categorie categorie = new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
						Evenement evenement = new Evenement(resultSet.getInt("idEvenement"), resultSet.getString("titreEvenement"),
								resultSet.getString("lieuEvenement"),resultSet.getDate("dateEvenement").toLocalDate(),categorie, resultSet.getString("descriptionEvent"));
						return new Video(resultSet.getInt("idVideo"), evenement, resultSet.getString("descriptionVideo"));
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
				
			
			}

	@Override
	public void removeVideo(Integer id) {
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement statement = connection.prepareStatement("UPDATE video SET deletedVideo=true WHERE idVideo=?")
						){
			statement.setInt(1,id);
			statement.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
			
	}
	
	

}
