package hei.projet.dao;

import java.util.List;

import javax.servlet.http.Part;

import hei.projet.entities.Categorie;

public interface CategorieDao {
	
	public List<Categorie> listCategories();
	
	public Categorie getCategorie(Integer id);
	
	public Categorie addCategorie (String libelle, String picture);
	
	public void removeCategorie(Integer idCategorie);
	
	public String getPicturePath (Integer id) ;

}