package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.services.CategorieService;
import hei.projet.services.PublicationService;

@WebServlet("/priveAdmin/deletecategorie")
public class CategorieDeleteServlet extends AbstractGenericServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String confirm = req.getParameter("confirm");
		Integer idCategorie = Integer.parseInt(req.getParameter("id"));
		if ("true".equals(confirm)){
			CategorieService.getInstance().removeCategorie(idCategorie);
			resp.sendRedirect("admingestioncategories");
			
		}else{
					
			TemplateEngine templateEngine = this.createTemplateEngine(req);
		
			WebContext context = new WebContext(req,resp, req.getServletContext());
		
			
			context.setVariable("categorie", CategorieService.getInstance().getCategorie(idCategorie));
		
			templateEngine.process("confirmdeletecategorie", context, resp.getWriter());
		
		}
		
	}
	
	

}
