package hei.projet.entities;

//Cette classe permet de représenter la table video de la base de données sous forme d'objet Java
// Cette classe représente les vidéos reçues par Saturne
public class Video {

	//Attribut de la classe Video
	private Integer id;
	private Evenement evenement;
	private String description;

	/**
    Constructeur de la classe Video
    @param id L'id de la video.  
    @param evenement L'evenement auquel est rattaché la video. 
    @param description La description de la video.
	 */
	public Video(Integer id, Evenement evenement, String description) {
		super();
		this.id = id;
		this.evenement = evenement;
		this.description = description;
	}
	
	/**
    Lire l'identifiant de la video reçue. 
    @return L'identifiant de la video. 
	 */
	public Integer getId() {
		return id;
	}
	
	/**
    Alterer l'id d'une vidéo reçue. 
    @param id L'id de la vidéo reçue. 
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
    Lire l'évènement auquel appartient la video reçue. 
    @return L'identifiant d'un evenement. 
	 */
	public Evenement getEvenement() {
		return evenement;
	}
	
	/**
    Alterer l'évènement auquel appartient la vidéo reçue. 
    @param evenement L'évènement auquel appartient la vidéo reçue.  
	 */
	public void setEvenement(Evenement evenement) {
		this.evenement = evenement;
	}
	
	/**
    Lire la description d'une vidéo reçue.  
    @return L'identifiant d'un evenement. 
	 */
	public String getDescription() {
		return description;
	}
	
	/**
    Alterer la description d'une vidéo reçue. 
    @param description de la vidéo. 
	 */
	public void setDescription(String description) {
		this.description = description;
	}


	

	
	
	


}
