package hei.projet.dao;

import java.util.List;
import hei.projet.entities.Text;

public interface TextDao {
	
	public List<Text> listTexts();
	
	public void updateText (Integer id, String contenu);

}
