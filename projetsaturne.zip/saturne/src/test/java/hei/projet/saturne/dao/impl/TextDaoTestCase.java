package hei.projet.saturne.dao.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import hei.projet.dao.TextDao;
import hei.projet.dao.impl.DataSourceProvider;
import hei.projet.dao.impl.TextDaoImpl;
import hei.projet.entities.Categorie;
import hei.projet.entities.Text;

public class TextDaoTestCase {
	
	private TextDao textDao = new TextDaoImpl();
	
	@Before
	public void initDb() throws Exception {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate("DELETE FROM text");
			stmt.executeUpdate("INSERT INTO `text`(`idText`,`textSite`) VALUES (1,'Hello')");
		}
	}
	
	@Test
	public void shouldListTexts() {
		// WHEN
		List<Text> texts = textDao.listTexts();
		// THEN
		assertThat(texts).hasSize(1);
		assertThat(texts).extracting("id", "contenu").containsOnly(tuple(1,"Hello"));
	}
	
}


