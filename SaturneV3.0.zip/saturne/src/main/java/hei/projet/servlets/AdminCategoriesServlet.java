package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.services.CategorieService;
import hei.projet.services.PublicationService;

@WebServlet("/priveAdmin/admingestioncategories")
@MultipartConfig
public class AdminCategoriesServlet extends AbstractGenericServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		TemplateEngine templateEngine = this.createTemplateEngine(req);
		
		WebContext context = new WebContext(req, resp, req.getServletContext());
		
		context.setVariable("categories", PublicationService.getInstance().listCategories());
		
		templateEngine.process("administration-listcategories", context, resp.getWriter());
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			String categorieNom = req.getParameter("categorieName");
			
			Part categoriePicture = req.getPart("categoriePicture");
			
	
			
			try{
				CategorieService.getInstance().addCategorie(categorieNom, categoriePicture);
				resp.sendRedirect("admingestioncategories");
			}catch(IOException e){
				req.getSession().setAttribute("categorieCreationErreur", e.getMessage());
			}
			}
			
			
		}
	