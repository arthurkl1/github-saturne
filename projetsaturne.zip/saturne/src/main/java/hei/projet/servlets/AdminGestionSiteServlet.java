package hei.projet.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.entities.Picture;
import hei.projet.entities.Text;
import hei.projet.services.PictureService;
import hei.projet.services.TextService;

@WebServlet("/priveAdmin/admingestionsite")
@MultipartConfig
public class AdminGestionSiteServlet extends AbstractGenericServlet {
	
	private static final long serialVersionUID = -3032812618526895052L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		TemplateEngine templateEngine = this.createTemplateEngine(req);
		
		WebContext context = new WebContext(req, resp, req.getServletContext());
				
		List<Picture> picturesList = PictureService.getInstance().listPicture();
		context.setVariable("pictures", picturesList);
		
		templateEngine.process("administration-gestionsite", context, resp.getWriter());
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setCharacterEncoding("UTF-8");		
					
			Part sitePicture = req.getPart("sitePicture");	
			Integer idPicture = Integer.parseInt(req.getParameter("id"));
			
			try {
				PictureService.getInstance().updatePicture(idPicture, sitePicture);
				//resp.sendRedirect("admingestionsite");
			}catch(IOException e){
				req.getSession().setAttribute("pictureUpdateErreur", e.getMessage());
			}
					
					
					
			resp.sendRedirect("admingestionsite");
		}

}
