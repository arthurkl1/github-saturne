package hei.projet.saturne.dao.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import hei.projet.dao.CategorieDao;
import hei.projet.dao.PictureDao;
import hei.projet.dao.impl.CategorieDaoImpl;
import hei.projet.dao.impl.DataSourceProvider;
import hei.projet.dao.impl.PictureDaoImpl;
import hei.projet.entities.Categorie;
import hei.projet.entities.Picture;

public class PictureDaoTestCase {
	
	private PictureDao pictureDao = new PictureDaoImpl();
	
	@Before
	public void initDb() throws Exception {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate("DELETE FROM picture");
			stmt.executeUpdate("INSERT INTO `picture`(`idPicture`,`pictureSite`) VALUES (1,'/path/to/picture1.png')");
			stmt.executeUpdate("INSERT INTO `picture`(`idPicture`,`PictureSite`) VALUES (2,'/path/to/picture2.png')");
		}
	}
	
	@Test
	public void shouldListPictures() {
		// WHEN
		List<Picture> pictures = pictureDao.listPictures();
		// THEN
		assertThat(pictures).hasSize(2);
	}
	
	@Test
	public void shouldGetPicturePath() {
		// WHEN
		String picturePath = pictureDao.getPicturePath(1);
		// THEN
		Assertions.assertThat(picturePath).isEqualTo("/path/to/picture1.png");
	}	

}
