package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.services.EtudiantService;

@WebServlet("/priveAdmin/adminetudiant")
public class DevenirAdminServlet extends AbstractGenericServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String confirm = req.getParameter("confirm");
		Integer idEtudiant = Integer.parseInt(req.getParameter("id"));
		if ("true".equals(confirm)){
			EtudiantService.getInstance().donnerDroitsAdmin(idEtudiant);
			resp.sendRedirect("admingestionetudiants");
			
		}else{
					
			TemplateEngine templateEngine = this.createTemplateEngine(req);
		
			WebContext context = new WebContext(req,resp, req.getServletContext());
		
			
			context.setVariable("etudiant", EtudiantService.getInstance().getEtudiant(idEtudiant));
		
			templateEngine.process("confirmadminetudiant", context, resp.getWriter());
		
		}
		
	}


}
