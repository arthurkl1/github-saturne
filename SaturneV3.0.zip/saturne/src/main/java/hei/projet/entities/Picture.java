package hei.projet.entities;

public class Picture {
	
	private Integer id;
	
	public Picture(Integer id){
		super();
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
