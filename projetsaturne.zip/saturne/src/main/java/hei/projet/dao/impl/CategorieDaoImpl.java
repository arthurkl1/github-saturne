package hei.projet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import hei.projet.dao.CategorieDao;
import hei.projet.entities.Categorie;

// Classe qui permet d'accéder et intéragire avec la bdd 

public class CategorieDaoImpl implements CategorieDao{
	
	/**
    Méthode qui permet de lister les catégories non supprimées en base, classées par ordre alphabétique du titre
    @return Liste des catégories.
	 */ 
	@Override
	public List<Categorie> listCategories() {
		//Requete a executer 
		String query = "SELECT * FROM categorie WHERE deletedCategorie = false ORDER BY titreCategorie";
		//Creation d'une liste de categories
		List<Categorie> categories = new ArrayList<>(); 
		
		//On récupère une connexion
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			//création du statement
			try (Statement statement = connection.createStatement()) {
				//récupération d'un resultSet
				try (ResultSet resultSet = statement.executeQuery(query)) {
					//on parcoure l'object resultSet, tant que dans le resultSet on a un element,
					//on transforme cet element en categorie, puis on l'ajoute à la liste. 
					//on recupere dans le resultSet les colonnes de la bdd. 
					while(resultSet.next()) {
						//
						Categorie categorie = new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
						categories.add(categorie);
					}
				}
			}
			//on catch la SQLException
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// on renvoie la liste de l'ensemble des catégories 
		return categories;
		
	}
	
	/**
   	Récupérer une catégorie.
    @param id Le numéro d'identifiant unique de la catégorie en base.
    @return La catégorie correspondant à l'id spécifié si il existe, sinon null.
	 */
	@Override
	public Categorie getCategorie(Integer id) {	
		//On récupère une connexion
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			//PreparedStatement ici, car la méthode que l'on execute est paramétrée
			//on veut récuperer une categorie particulière, cette catégorie doit avoir l'id envoyé en paramètre et deletedCategorie à false
			try(PreparedStatement statement = connection.prepareStatement("SELECT * FROM categorie WHERE idCategorie = ? AND deletedCategorie=false")) {
				// le  "?" n°1, on lui donne la valeur "id"
				statement.setInt(1, id);
				//Execution de la requête et on récupère un resultSet
				try (ResultSet resultSet = statement.executeQuery()) {
					//boucle if car on sait que l'on aura 1 ou 0 résultats (si 0 on ne passe pas dans le if)  
					if(resultSet.next()) {
						//on retourne une nouvelle catégorie
						return new Categorie(resultSet.getInt("idCategorie"), resultSet.getString("titreCategorie"), resultSet.getString("pictureCategorie"));
					}
				}
			}
			//on catch la SQLException
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
    Ajouter une catégorie
    @param nom Le nom de la catégorie
    @param picturePath L'image de la catégorie
    @return La nouvelle catégorie ajoutée en base
	 */
	@Override
	public Categorie addCategorie(String nom, String picturePath) {
		//On récupère une connexion
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			//On crée un statement 
			//Le paramètre supplémentaire "Statement.RETURN_GENERATED_KEYS"
			// permet de spécifier que si on execute une requete, 
			//on veut recevoir en resultat les clés générées par la requete
			try(PreparedStatement statement = connection.prepareStatement("INSERT INTO categorie(titreCategorie, pictureCategorie) VALUES(?,?)", 
					Statement.RETURN_GENERATED_KEYS)) {
				//On remplit les "?", le n°1 correspond au nom, le n°2 au picturePath
				statement.setString(1, nom);
				statement.setString(2, picturePath);
				//On execute la requete
				statement.executeUpdate();
				//On récupere la clé générée par la requête (getGeneratedKeys)
				try (ResultSet resultSet = statement.getGeneratedKeys()) {
					if(resultSet.next()) {
						return new Categorie(resultSet.getInt(1), nom, picturePath);
					}
				}
			}
			//on catch la SQLException
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
    Supprimer une catégorie
    @param id L'id de la catégorie à supprimer
	 */
	public void removeCategorie(Integer id){
		//On récupère une connexion
		try(Connection connection = DataSourceProvider.getDataSource().getConnection();
				//récupération d'un resultSet
				PreparedStatement statement = connection.prepareStatement("UPDATE categorie SET deletedCategorie=true WHERE idCategorie=?")
						){
			statement.setInt(1,id);
			statement.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
			
		}

	/**
    Récuperer le chemin en base de l'image d'une catégorie
    @param id L'identifiant de la catégorie. 
    @return Le chemin en base de la catégorie correspondant à l'id spécifié. 
	 */
	@Override
	public String getPicturePath(Integer id) {
		//On récupère une connexion
		try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
			//récupération d'un resultSet
			try(PreparedStatement statement = connection.prepareStatement("SELECT pictureCategorie FROM categorie WHERE idCategorie = ? AND deletedCategorie=false")) {
				statement.setInt(1, id);
				try (ResultSet resultSet = statement.executeQuery()) {
					if(resultSet.next()) {
						return resultSet.getString("pictureCategorie");
					}
				}
			}
			//on catch la SQLException
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	}
