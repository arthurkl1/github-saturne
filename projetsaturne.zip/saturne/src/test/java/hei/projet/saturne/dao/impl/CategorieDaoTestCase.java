package hei.projet.saturne.dao.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import hei.projet.dao.CategorieDao;
import hei.projet.dao.impl.CategorieDaoImpl;
import hei.projet.dao.impl.DataSourceProvider;
import hei.projet.entities.Categorie;
import hei.projet.entities.Publication;

// Classe qui permet de tester le code inscrit dans CategorieDaoImpl
// permet de tester si les méthodes dans CategorieDaoImpl sont bien implémentées

public class CategorieDaoTestCase {
	
	private CategorieDao categorieDao = new CategorieDaoImpl();

	@Before
	public void initDb() throws Exception {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate("DELETE FROM categorie");
			stmt.executeUpdate("INSERT INTO `categorie`(`idCategorie`,`titreCategorie`, deletedCategorie, pictureCategorie) VALUES (1,'Administration', false, '/path/to/picture1.png')");
			stmt.executeUpdate("INSERT INTO `categorie`(`idCategorie`,`titreCategorie`, deletedCategorie, pictureCategorie) VALUES (2,'BDA', false, '/path/to/picture2.png')");
			stmt.executeUpdate("INSERT INTO `categorie`(`idCategorie`,`titreCategorie`, deletedCategorie, pictureCategorie) VALUES (3,'BDE',false, '/path/to/picture3.png')");
			stmt.executeUpdate("INSERT INTO `categorie`(`idCategorie`,`titreCategorie`, deletedCategorie, pictureCategorie) VALUES (4,'BDS',true, '/path/to/picture4.png')");
		}
	}

	@Test
	public void shouldListCategories() {
		// WHEN
		List<Categorie> categories = categorieDao.listCategories();
		// THEN
		assertThat(categories).hasSize(3);
		assertThat(categories).extracting("id", "nom").containsOnly(/*tuple(4, "BDS"),*/ tuple(3, "BDE"),tuple(2,"BDA"),tuple(1,"Administration"));
	}

	@Test
	public void shouldGetCategorie() {
		// WHEN
		Categorie categorie = categorieDao.getCategorie(1);
		// THEN
		assertThat(categorie).isNotNull();
		assertThat(categorie.getId()).isEqualTo(1);
		assertThat(categorie.getNom()).isEqualTo("Administration");
	}
	
	@Test
	public void shouldNotGetCategorie() {
		// WHEN
		Categorie categorie = categorieDao.getCategorie(4);
		// THEN
		Assertions.assertThat(categorie).isNull();
	}

	@Test
	public void shouldAddCategorie() throws Exception {
		// WHEN
		Categorie categorie = categorieDao.addCategorie("test","/path/to/picture.png");
		// THEN
		assertThat(categorie.getId()).isNotNull();
		assertThat(categorie.getNom()).isEqualTo("test");

		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("SELECT * FROM categorie WHERE idCategorie = ?")) {
			stmt.setInt(1, categorie.getId());
			try (ResultSet rs = stmt.executeQuery()) {
				assertThat(rs.next()).isTrue();
				assertThat(rs.getInt("idCategorie")).isEqualTo(categorie.getId());
				assertThat(rs.getString("titreCategorie")).isEqualTo("test");
				assertThat(rs.getString("pictureCategorie")).isEqualTo("/path/to/picture.png");
				assertThat(rs.next()).isFalse();
			}
		}
	}
	
	@Test 
	public void shouldDeleteCategorie() throws Exception{
		//WHEN
		categorieDao.removeCategorie(3);
		//THEN 
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("SELECT * FROM categorie WHERE idCategorie=3")) {
			Assertions.assertThat(resultSet.next()).isTrue();
			assertThat(resultSet.getInt("idCategorie")).isNotNull();
			assertThat(resultSet.getString("titreCategorie")).isEqualTo("BDE");
			assertThat(resultSet.getBoolean("deletedCategorie")).isTrue();
			assertThat(resultSet.next()).isFalse();
			
			
		}
	}
	
	@Test
	public void shouldGetPicturePath() {
		// WHEN
		String picturePath = categorieDao.getPicturePath(1);
		// THEN
		Assertions.assertThat(picturePath).isEqualTo("/path/to/picture1.png");
	}

}