package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.entities.Etudiant;
import hei.projet.exceptions.SaturneSecuriteException;
import hei.projet.services.EtudiantService;

	@WebServlet("/priveAdmin/adminparametrescompte")
public class AdminParametresCompteServlet extends GenericSaturneServlet {

		private static final long serialVersionUID = -3032812618526895052L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		TemplateEngine templateEngine = this.createTemplateEngine(req);
		
		WebContext context = new WebContext(req, resp, req.getServletContext());
		
		templateEngine.process("administration-parametrescompte", context, resp.getWriter());
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String motDePasse = request.getParameter("motDePasse");
		String motDePasseConfirmation = request.getParameter("motDePasseConfirm");
		try {
			Etudiant etudiant = (Etudiant) request.getSession().getAttribute("utilisateurAdminConnecte");
			EtudiantService.getInstance().modifierMotDePasse(etudiant.getId(), motDePasse, motDePasseConfirmation);
			this.ajouterMessageSucces(request, "Le mot de passe a ete modifie avec succes.");
		} catch (IllegalArgumentException e) {
			this.ajouterMessageErreur(request, e.getMessage());
		} catch (SaturneSecuriteException e) {
			this.ajouterMessageErreur(request, "Problème technique, merci de contacter un administrateur.");
		}
		response.sendRedirect("adminparametrescompte");
	}
}
