CREATE TABLE `categorie`(
	`idCategorie` int(11) NOT NULL AUTO_INCREMENT,
	`titreCategorie` varchar(50) NOT NULL,
    `deletedCategorie` bit(1) NULL DEFAULT 0,
    `pictureCategorie` Varchar(100) NULL,
	PRIMARY KEY (`idCategorie`)
);

CREATE TABLE `publication`(
	`idPublication` int(11) NOT NULL AUTO_INCREMENT,
	`titrePublication` varchar(500) NOT NULL,
    `datePublication` date NOT NULL,
    `lienPublication` varchar(5000) NOT NULL,
    `idCategorie` int(11) NOT NULL,
    `deletedPublication` bit(1) NULL DEFAULT 0,
	PRIMARY KEY (`idPublication`),
    KEY `idCategorie_fk` (`idCategorie`),
  CONSTRAINT `idCategorie_fk` FOREIGN KEY (`idCategorie`) REFERENCES `categorie` (`idCategorie`)
    
);

CREATE TABLE `evenement`(
	`idEvenement` int(11) NOT NULL AUTO_INCREMENT,
	`titreEvenement` varchar(500) NOT NULL,
	`lieuEvenement` varchar(500) NOT NULL,
    `dateEvenement` date NOT NULL,
	`idCategorie` int(11) NOT NULL,
    `deletedEvenement` bit(1) NULL DEFAULT 0,
    `descriptionEvent` varchar(5000) NOT NULL,
	PRIMARY KEY (`idEvenement`),
    KEY `idCategorie_fk2` (`idCategorie`),
  CONSTRAINT `idCategorie_fk2` FOREIGN KEY (`idCategorie`) REFERENCES `categorie` (`idCategorie`) 
);

CREATE TABLE `video`(
	`idVideo` int(11) NOT NULL AUTO_INCREMENT,
	`idEvenement` int(11) NOT NULL,
    `descriptionVideo` varchar(5000) NOT NULL,
    `deletedVideo` bit(1) NULL DEFAULT 0,
    `lienVideo` varchar(5000) NOT NULL,
	PRIMARY KEY (`idVideo`),
    KEY `idEvenement_fk3` (`idEvenement`),
  CONSTRAINT `idEvenement_fk3` FOREIGN KEY (`idEvenement`) REFERENCES `evenement` (`idEvenement`)
);

CREATE TABLE `etudiant`(
	`idEtudiant` int(11) NOT NULL AUTO_INCREMENT,
	`mailEtudiant` varchar(100) NOT NULL,
    `mdpEtudiant` varchar(100) NOT NULL,
    `deletedEtudiant` bit(1) NULL DEFAULT 0,
    `admin` bit(1) NULL DEFAULT 0,
	PRIMARY KEY (`idEtudiant`)
);

CREATE TABLE `text` (
  `idText` int(11) NOT NULL AUTO_INCREMENT,
  `textSite` varchar(10000) NOT NULL,
  PRIMARY KEY (`idText`)
);


CREATE TABLE `picture` (
  `idPicture` int(11) NOT NULL AUTO_INCREMENT,
  `pictureSite` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idPicture`)
);