package hei.projet.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.entities.Text;
import hei.projet.services.TextService;

@WebServlet("/priveAdmin/admingestionsitetext")
public class AdminGestionSiteTextServlet extends AbstractGenericServlet {
		
		private static final long serialVersionUID = -3032812618526895052L;
		
		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			TemplateEngine templateEngine = this.createTemplateEngine(req);
			
			WebContext context = new WebContext(req, resp, req.getServletContext());
			
			List<Text> textsList = TextService.getInstance().listText();
			context.setVariable("texts", textsList);
						
			templateEngine.process("administration-gestionsitetext", context, resp.getWriter());
		}
		
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			resp.setCharacterEncoding("UTF-8");		
				
				Integer idText = Integer.parseInt(req.getParameter("id"));
				//Integer idText = 1;
				String contenu = req.getParameter("textSite");					
				
				TextService.getInstance().updateText(idText, contenu);
						
				resp.sendRedirect("admingestionsitetext");
			}


}
