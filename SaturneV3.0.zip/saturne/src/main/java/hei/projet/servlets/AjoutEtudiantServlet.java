package hei.projet.servlets;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hei.projet.entities.Etudiant;
import hei.projet.exceptions.SaturneSecuriteException;
import hei.projet.services.EtudiantService;

@WebServlet("/ajouterEtudiant")
public class AjoutEtudiantServlet extends HttpServlet {

	
	
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
			resp.setCharacterEncoding("UTF-8");
			
			String mailEtudiant = req.getParameter("email");
			String motDePasse = req.getParameter("password");
			String motDePasseConf = req.getParameter("passwordConf");
			
			
			Etudiant etudiantToAdd = new Etudiant(null, mailEtudiant,false);
			if(motDePasse.equals(motDePasseConf)){
			try {
				EtudiantService.getInstance().ajouterEtudiant(etudiantToAdd,motDePasse);
			} catch (SaturneSecuriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}else{
				System.out.println("pas identique");
			}
			resp.sendRedirect("authentification");
			
		}
	}


