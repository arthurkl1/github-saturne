package hei.projet.servlets;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hei.projet.services.CategorieService;

@WebServlet("/prive/categoriePicture")
public class CategoriePictureServlet extends AbstractGenericServlet {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6718791971955374375L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println("accés a la servelt");
		Integer categorieId = Integer.parseInt(req.getParameter("id"));
		Path picturePath = CategorieService.getInstance().getPicturePath(categorieId);
		
		
		Files.copy(picturePath, resp.getOutputStream());
	}
	
	
} 
