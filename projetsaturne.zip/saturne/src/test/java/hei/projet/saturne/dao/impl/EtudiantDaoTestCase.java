package hei.projet.saturne.dao.impl;


import java.sql.Connection;
import java.sql.Statement;

import org.junit.Before;

import hei.projet.dao.EtudiantDao;
import hei.projet.dao.impl.DataSourceProvider;
import hei.projet.dao.impl.EtudiantDaoImpl;

public class EtudiantDaoTestCase {
	
	private EtudiantDao etudiantDao = new EtudiantDaoImpl();
	
	@Before
	public void initDb() throws Exception {
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()) {
			stmt.executeUpdate("DELETE FROM etudiant");
			stmt.executeUpdate("INSERT INTO `etudiant`(`idEtudiant`,`mailEtudiant`,`mdpEtudiant`, deletedEtudiant, admin) VALUES (1,'admin@hei.fr', 'admin', false, true)");
			stmt.executeUpdate("INSERT INTO `etudiant`(`idEtudiant`,`mailEtudiant`,`mdpEtudiant`, deletedEtudiant, admin) VALUES (2,'etudiant@hei.fr', 'etudiant', false, false)");
			stmt.executeUpdate("INSERT INTO `etudiant`(`idEtudiant`,`mailEtudiant`,`mdpEtudiant`, deletedEtudiant, admin) VALUES (3,'suppr@hei.fr', 'suppr', true, true)");
		}
	}

}
