package hei.projet.entities;

//Cette classe permet de représenter la table etudiant de la base de données sous forme d'objet Java

public class Etudiant {
	
	//Attribut de la classe Etudiant
		private Integer id;
		private String email;
		private boolean admin;
		
		/**
	    Constructeur de la classe Etudiant.
	    @param id L'id de l'étudiant.  
	    @param email L'email de l'étudiant. 
	    @param admin L'information relative au role de l'étudiant, administrateur ou non.  
		 */
		public Etudiant(Integer id, String email, boolean admin){
			super();
			this.id = id;
			this.email = email;
			this.setAdmin(admin);
		}

		
		/**
	    Lire l'identifiant d'un étudiant. 
	    @return L'identifiant d'un étudiant. 
		 */
		public Integer getId() {
			return id;
		}

		/**
	    Alterer l'identifiant d'un étudiant.
	    @param id L'identifiant de l'étudiant. 
		 */
		public void setId(Integer id) {
			this.id = id;
		}

		/**
	    Lire l'email d'un étudiant. 
	    @return l'email de l'étudiant. 
		 */
		public String getEmail() {
			return email;
		}
		
		/**
	    Alterer l'email d'un étudiant. 
	    @param email L'email de l'étudiant. 
		 */
		public void setEmail(String email) {
			this.email = email;
		}
		
		/**
	    Lire le rôle d'un étudiant. 
	    @return Le rôle de l'étudiant étudiant. 
		 */
		public boolean isAdmin() {
			return admin;
		}
		
		/**
	    Alterer le rôle d'un étudiant.
	    @param admin Le booleen indiquant le rôle de l'étudiant (1 Admin, 0 Pas admin). 
		 */
		public void setAdmin(boolean admin) {
			this.admin = admin;
		}
		
}
