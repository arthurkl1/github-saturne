package hei.projet.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import hei.projet.services.EvenementService;
import hei.projet.services.PublicationService;

@WebServlet("/priveAdmin/deleteevenement")
public class EvenementDeleteServlet extends AbstractGenericServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String confirm = req.getParameter("confirm");
		Integer idEvenement = Integer.parseInt(req.getParameter("id"));
		if ("true".equals(confirm)){
			EvenementService.getInstance().removeEvenement(idEvenement);
			resp.sendRedirect("admingestionevenements");
			
		}else{
					
			TemplateEngine templateEngine = this.createTemplateEngine(req);
		
			WebContext context = new WebContext(req,resp, req.getServletContext());
		
			
			context.setVariable("evenement", EvenementService.getInstance().getEvenement(idEvenement));
		
			templateEngine.process("confirmdeleteevenement", context, resp.getWriter());
		
		}
		
	}
	
	

}
